var tacos = [
  {
    name: "Puerco al Pastor",
    description:
      "marinated & sauteéd pork, pineapple, chihuahua cheese, onion, cilantro, chile de arbol salsa",
    selected: false,
    cost: 10.99,
  },
  {
    name: "Birria",
    description:
      "braised lamb leg, fundido cheese, cilantro, onion, crispy grilled adobo tortilla, watercress salad, habanero salsa",
    selected: false,
    cost: 10.99,
  },
  {
    name: "Coliflor o Portobello ",
    description:
      "cumin & turmeric roasted cauliflower OR cilantro grilled portobello mushroom, pumpkin seed pesto, smoked cashew salsa",
    selected: true,
    cost: 10.99,
  },
  {
    name: "Pollo",
    description: "chipotle chicken, diced onion, cilantro, mexicana salsa",
    selected: false,
    cost: 10.99,
  },
  {
    name: "Carne Asada",
    description:
      "marinated & grilled all-natural steak, diced onion, cilantro, guajillo salsa",
    selected: false,
    cost: 10.99,
  },
  {
    name: "Camarón o Pescado",
    description:
      "fried shrimp or grouper, poblano slaw, chipotle mayo, cruda tomatillo salsa",
    selected: false,
    cost: 10.99,
  },
  {
    name: "Pescado a la Parrilla",
    description:
      "citrus-grilled catch of the day, charred pico de gallo, avocado, cruda tomatillo salsa",
    selected: false,
    cost: 10.99,
  },
];
